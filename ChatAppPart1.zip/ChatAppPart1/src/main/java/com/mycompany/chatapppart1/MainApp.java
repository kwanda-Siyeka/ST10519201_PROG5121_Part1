/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatapppart1;

import java.util.Scanner;
/**
 *
 * @author kwanda
 */
//This class runs the main program(registration and login)
public class MainApp {
    public static void main(String[] args) {
        //This creates a Scanner object to get user input
        Scanner input = new Scanner(System.in);
        
        //Create Login object to use registration and login method
        Login login = new Login();
        
        //========== Registration Section ==========
        
        //Get username from user
        System.out.print("Enter a username: ");
        String username = input.nextLine();
        
        //Get password from user
        System.out.print("Enter a password: ");
        String password = input.nextLine();
        
        //Get phone number from user
        System.out.print("Enter your South African phone number (+27...): ");
        String phone = input.nextLine();
        
        String response = login.registerUser(username, password, phone);
        
        //Register user and store response message
        System.out.println(response);
        
        
        //========== Login Section ==========
        System.out.println("\n=== USER LOGIN ===");
            
        //Get login username
        System.out.print("Enter your username: ");
        String loginUsername = input.nextLine();
            
        //Get login password
        System.out.print("Enter your password: ");
        String loginPassword = input.nextLine();
            
        //check if login is correct
        boolean loggedIn = login.loginUser(loginUsername, loginPassword);
            
        //Show login message (success or failure)
        String loginMessage = login.returnLoginStatus(loggedIn);
        System.out.println(loginMessage);
       
        
        
  
    }
    
}
